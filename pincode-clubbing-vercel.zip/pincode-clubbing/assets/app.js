(function(){
"use strict";

const STATUS = {
  AGENT_TO_BE_ASSIGNED:        {label:"Agent to be assigned", kind:"pending"},
  DELIVERY_DATE_TO_BE_ASSIGNED:{label:"Date to be assigned",  kind:"pending"},
  DELIVERY_PARTNER_ASSIGNED:   {label:"Partner assigned",     kind:"active"},
  OUT_FOR_DELIVERY:            {label:"Out for delivery",     kind:"active"}
};
const REQUIRED = ["order id","address","order status","payment status"];

const $ = id => document.getElementById(id);
const esc = s => String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

const store = {
  get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
};

// Done marks live in memory only; they contain order IDs, so they are never written to storage.
let ALL = [], ELIGIBLE = [], doneSet = new Set();
const state = {branch:"", date:"", statuses:new Set(Object.keys(STATUS)), q:"", sort:"pending", hideDone:false};
const checked = new Map(); // orderId -> bool (row selection for copy)

/* ---------- Parsing ---------- */
function normKey(k){return String(k||"").replace(/\s+/g," ").trim().toLowerCase()}
function cellStr(v){
  if(v==null) return "";
  if(v instanceof Date){const d=String(v.getDate()).padStart(2,"0"),m=String(v.getMonth()+1).padStart(2,"0");return d+"/"+m+"/"+v.getFullYear()}
  const t=String(v).trim();
  return /^(n\/?a|null|none|nan|-+)$/i.test(t) ? "" : t;
}
function parseDMY(s){
  const m=/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(s||"");
  return m? new Date(+m[3],+m[2]-1,+m[1]).getTime() : null;
}
function extractPin(addr){
  const a=String(addr||"").trim();
  let m=/(\d{6})\s*,?\s*INDIA\s*\.?\s*$/i.exec(a);
  if(m) return m[1];
  const all=a.match(/\b\d{6}\b/g);
  return all? all[all.length-1] : "";
}
function extractPlace(addr){
  const parts=String(addr||"").split(",").map(s=>s.trim()).filter(Boolean);
  // ..., locality, city, state, pin, INDIA
  const i=parts.findIndex(p=>/^\d{6}$/.test(p));
  if(i>=2){
    const city=parts[i-2], loc=parts[i-3]||"";
    const ok=loc && !/^\d/.test(loc) && !/\d{6}/.test(loc) && loc.length<40 && loc.toLowerCase()!==city.toLowerCase();
    return {city, locality: ok ? loc.replace(/[.,\s]+$/,"") : ""};
  }
  return {city:"",locality:""};
}

function rowsFromSheet(ws){
  const rows=XLSX.utils.sheet_to_json(ws,{defval:"",raw:false});
  return rows.map(r=>{const o={};for(const k in r)o[normKey(k)]=cellStr(r[k]);return o});
}

function ingest(rows){
  if(!rows.length) throw new Error("No rows found. Check that the first row is the header row.");
  const keys=Object.keys(rows[0]);
  const missing=REQUIRED.filter(k=>!keys.includes(k));
  if(missing.length) throw new Error("Missing column"+(missing.length>1?"s":"")+": "+missing.map(m=>m.replace(/\b\w/g,c=>c.toUpperCase())).join(", ")+". Use the Page Selection Info export from the OMS.");
  ALL=rows.filter(r=>r["order id"]).map(r=>{
    const p=extractPlace(r["address"]);
    return {
      id:r["order id"], name:r["name"], address:r["address"],
      pin:extractPin(r["address"]), city:p.city, locality:p.locality,
      status:(r["order status"]||"").toUpperCase(),
      payment:(r["payment status"]||"").toUpperCase(),
      verification:(r["verification status"]||"").toUpperCase(),
      cancel:(r["cancellation status"]||"").toUpperCase(),
      deliveryDate:r["delivery date"]||"", deliveryTs:parseDMY(r["delivery date"]),
      travelDate:r["travel date"]||"", travelTs:parseDMY(r["travel date"]),
      branch:r["branch"]||"—", currency:r["currency"]||"", amount:r["amount"]||"",
      customer:r["customer id"]||""
    };
  });
  ELIGIBLE=ALL.filter(o=>o.payment==="FULL_PAYMENT_DONE" && STATUS[o.status] && o.pin);
  checked.clear();
  ELIGIBLE.forEach(o=>checked.set(o.id, STATUS[o.status].kind==="pending"));
  setupFilters();
  renderSummary();
  $("intake").hidden=true; $("results").hidden=false; $("topActions").hidden=false;
  render();
}

function readFile(f){
  $("err").textContent="";
  const rd=new FileReader();
  rd.onload=e=>{
    try{
      const wb=XLSX.read(new Uint8Array(e.target.result),{type:"array",cellDates:true});
      ingest(rowsFromSheet(wb.Sheets[wb.SheetNames[0]]));
    }catch(err){$("err").textContent=err.message||"Could not read that file."}
  };
  rd.onerror=()=>{$("err").textContent="Could not read that file."};
  rd.readAsArrayBuffer(f);
}
function readPaste(){
  $("err").textContent="";
  const t=$("paste").value.trim();
  if(!t){$("err").textContent="Paste the rows first, including the header row.";return}
  try{
    const wb=XLSX.read(t,{type:"string",FS:t.includes("\t")?"\t":","});
    ingest(rowsFromSheet(wb.Sheets[wb.SheetNames[0]]));
  }catch(err){$("err").textContent=err.message||"Could not read the pasted rows."}
}

/* ---------- Summary ---------- */
function renderSummary(){
  const groups=groupByPin(ELIGIBLE);
  const multi=groups.filter(g=>g.orders.length>1);
  const clubbable=multi.reduce((a,g)=>a+g.orders.length,0);
  $("summary").innerHTML=
    cell(ALL.length,"orders in the dump")+
    cell(ELIGIBLE.length,"fully paid and in delivery stages")+
    cell(multi.length,"pincodes with 2 or more orders")+
    cell(clubbable,"orders that can be clubbed")+
    cell(groups.length-multi.length,"pincodes with a single order");
  function cell(n,l){return `<div><b>${n}</b><span>${l}</span></div>`}

  const reasons={};
  ALL.forEach(o=>{
    if(ELIGIBLE.includes(o)) return;
    let r;
    if(o.payment!=="FULL_PAYMENT_DONE") r="Payment not full ("+(o.payment||"blank").toLowerCase().replace(/_/g," ")+")";
    else if(!STATUS[o.status]) r="Status not in delivery stages ("+(o.status||"blank").toLowerCase().replace(/_/g," ")+")";
    else r="No pincode found in address";
    reasons[r]=(reasons[r]||0)+1;
  });
  const n=ALL.length-ELIGIBLE.length;
  $("excluded").innerHTML = n? `<summary>${n} orders left out. See why</summary><ul>${
    Object.entries(reasons).sort((a,b)=>b[1]-a[1]).map(([r,c])=>`<li>${esc(r)}: ${c}</li>`).join("")}</ul>` : "";
  $("excluded").hidden=!n;
}

/* ---------- Filters ---------- */
function setupFilters(){
  const branches=[...new Set(ELIGIBLE.map(o=>o.branch))].sort();
  $("fBranch").innerHTML=`<option value="">All branches</option>`+branches.map(b=>`<option>${esc(b)}</option>`).join("");
  const dates=[...new Set(ELIGIBLE.filter(o=>o.deliveryDate).map(o=>o.deliveryDate))].sort((a,b)=>parseDMY(a)-parseDMY(b));
  $("fDate").innerHTML=`<option value="">Any delivery date</option><option value="__none">Date not set</option>`+dates.map(d=>`<option>${esc(d)}</option>`).join("");
  $("fStatus").innerHTML=Object.entries(STATUS).map(([k,v])=>`<button class="chip" data-s="${k}" aria-pressed="true">${v.label}</button>`).join("");
  state.branch="";state.date="";state.statuses=new Set(Object.keys(STATUS));state.q="";
  $("fSearch").value="";
}
function filtered(){
  const q=state.q.toLowerCase();
  return ELIGIBLE.filter(o=>
    (!state.branch||o.branch===state.branch) &&
    state.statuses.has(o.status) &&
    (!state.date || (state.date==="__none"? !o.deliveryDate : o.deliveryDate===state.date))
  ).filter(o=>!q || [o.pin,o.id,o.name,o.city,o.locality,o.address].some(v=>String(v).toLowerCase().includes(q)));
}

/* ---------- Grouping & advice ---------- */
function groupByPin(list){
  const m=new Map();
  list.forEach(o=>{if(!m.has(o.pin))m.set(o.pin,[]);m.get(o.pin).push(o)});
  return [...m.entries()].map(([pin,orders])=>{
    orders.sort((a,b)=>(STATUS[a.status].kind===STATUS[b.status].kind?0:STATUS[a.status].kind==="pending"?-1:1)||((a.travelTs||9e15)-(b.travelTs||9e15)));
    const pending=orders.filter(o=>STATUS[o.status].kind==="pending");
    const active=orders.filter(o=>STATUS[o.status].kind==="active");
    const cities=[...new Set(orders.map(o=>o.city).filter(Boolean))];
    const seen=new Set(),locs=[];orders.forEach(o=>{const k=(o.locality||"").toLowerCase();if(k&&!seen.has(k)){seen.add(k);locs.push(o.locality)}});
    const earliest=Math.min(...orders.map(o=>o.travelTs||9e15));
    return {pin,orders,pending,active,cities,locs,earliest,key:pin+"|"+orders.map(o=>o.id).sort().join(",")};
  });
}
function fmt(ts){if(!ts||ts>8e15)return "";const d=new Date(ts);return String(d.getDate()).padStart(2,"0")+"/"+String(d.getMonth()+1).padStart(2,"0")}
function advice(g){
  const out=[];
  const P=g.pending.length, A=g.active.length;
  if(P&&A){
    out.push(`An agent already has ${A} order${A>1?"s":""} here (${g.active.map(o=>STATUS[o.status].label.toLowerCase()).filter((v,i,a)=>a.indexOf(v)===i).join(", ")}). Add the ${P} pending order${P>1?"s":""} to that agent.`);
  }else if(P>1){
    out.push(`Assign these ${P} orders to one agent.`);
  }else if(A>1){
    out.push(`All ${A} orders are already with a partner. Check they are on the same agent.`);
  }
  const noDate=g.pending.filter(o=>!o.deliveryDate);
  if(noDate.length){
    const t=Math.min(...noDate.map(o=>o.travelTs||9e15));
    out.push(`${noDate.length} order${noDate.length>1?"s need":" needs"} a delivery date${fmt(t)?`; earliest travel is ${fmt(t)}`:""}.`);
  }
  const dated=[...new Set(g.orders.filter(o=>o.deliveryDate).map(o=>o.deliveryDate))];
  if(dated.length>1) out.push(`Delivery dates differ (${dated.map(d=>d.slice(0,5)).join(", ")}). Align them to one run.`);
  const byCust={};g.orders.forEach(o=>{if(o.customer)(byCust[o.customer]=byCust[o.customer]||[]).push(o)});
  Object.values(byCust).filter(a=>a.length>1).forEach(a=>out.push(`${a.length} orders are from the same customer (${esc(a[0].name)}). Deliver in one visit.`));
  const br=[...new Set(g.orders.map(o=>o.branch))];
  if(br.length>1) out.push(`Orders span branches: ${br.map(esc).join(", ")}.`);
  return out;
}

/* ---------- Render ---------- */
function flags(o,g){
  const f=[];
  if(o.cancel) f.push(`<span class="flag">${o.cancel==="CANCEL_REQUEST_ACCEPTED"?"Cancel accepted":"Cancel requested"}</span>`);
  if(o.verification && o.verification!=="VERIFIED") f.push(`<span class="flag">${esc(o.verification.toLowerCase().replace(/_/g," "))}</span>`);
  if(g && o.customer && g.orders.filter(x=>x.customer===o.customer).length>1) f.push(`<span class="flag info">Same customer</span>`);
  return f.join("");
}
function amountHTML(o){
  const c=String(o.currency).split(",").map(x=>x.trim()).filter(Boolean), a=String(o.amount).split(",").map(x=>x.trim()).filter(Boolean);
  if(c.length>1 && c.length===a.length) return c.map((x,i)=>esc(x+" "+a[i])).join("<br>");
  return esc((o.currency+" "+o.amount).trim());
}
function shortAddr(a){return String(a||"").replace(/,\s*[^,]*,\s*[^,]*,\s*\d{6}\s*,\s*INDIA\s*\.?\s*$/i,"").replace(/[,\s]+$/,"")}
function rowHTML(o,g,withChk){
  const s=STATUS[o.status];
  return `<tr>
    ${withChk?`<td class="chk"><input type="checkbox" data-row="${esc(o.id)}" ${checked.get(o.id)?"checked":""} aria-label="Include ${esc(o.id)} in copy"></td>`:""}
    <td><button class="oid" data-copy="${esc(o.id)}" title="Copy order ID">${esc(o.id)}</button><div>${flags(o,g)}</div></td>
    <td><div class="nm">${esc(o.name)}</div><div class="addr hide-sm" title="${esc(o.address)}">${esc(shortAddr(o.address))}</div></td>
    <td><span class="pill ${s.kind}">${s.label}</span></td>
    <td class="nowrap">${o.deliveryDate?esc(o.deliveryDate):'<span class="dim">Not set</span>'}</td>
    <td class="nowrap">${esc(o.travelDate)}</td>
    <td class="nowrap">${amountHTML(o)}</td>
    ${withChk?"":`<td class="nowrap">${esc(o.branch)}</td>`}
  </tr>`;
}
const HEAD=chk=>`<thead><tr>${chk?'<th></th>':''}<th>Order ID</th><th>Customer</th><th>Status</th><th>Delivery</th><th>Travel</th><th>Amount</th></tr></thead>`;

function render(){
  const groups=groupByPin(filtered());
  let multi=groups.filter(g=>g.orders.length>1);
  const singles=groups.filter(g=>g.orders.length===1);
  if(state.hideDone) multi=multi.filter(g=>!doneSet.has(g.key));
  const sorters={
    pending:(a,b)=>b.pending.length-a.pending.length||b.orders.length-a.orders.length||a.earliest-b.earliest,
    size:(a,b)=>b.orders.length-a.orders.length||a.earliest-b.earliest,
    travel:(a,b)=>a.earliest-b.earliest||b.orders.length-a.orders.length,
    pin:(a,b)=>a.pin.localeCompare(b.pin)
  };
  multi.sort(sorters[state.sort]);

  $("lanes").innerHTML = multi.length ? multi.map(g=>{
    const isDone=doneSet.has(g.key);
    const sel=g.orders.filter(o=>checked.get(o.id)).length;
    const adv=advice(g);
    return `<article class="lane${isDone?" done":""}" data-key="${esc(g.key)}">
      <div class="pinbox">
        <div class="pin">${esc(g.pin)}</div>
        <div class="place">${esc([g.locs.slice(0,2).join(", "),g.cities.join(", ")].filter(Boolean).join(" in "))}</div>
        <div class="place">${[...new Set(g.orders.map(o=>o.branch))].map(esc).join(", ")} branch</div>
        <div class="count">${g.orders.length} orders${g.pending.length?`, ${g.pending.length} to assign`:""}</div>
      </div>
      <div class="lane-body">
        <div class="advice">
          <ul>${adv.map(a=>`<li>${a}</li>`).join("")||"<li>Club these orders on one agent.</li>"}</ul>
          <div class="acts">
            <button class="btn primary small" data-copylane="${esc(g.key)}" ${sel?"":"disabled"}>Copy ${sel} ID${sel===1?"":"s"}</button>
            <label class="toggle"><input type="checkbox" data-done="${esc(g.key)}" ${isDone?"checked":""}> Done</label>
          </div>
        </div>
        <div class="tbl"><table>${HEAD(true)}<tbody>${g.orders.map(o=>rowHTML(o,g,true)).join("")}</tbody></table></div>
      </div>
    </article>`;
  }).join("") : `<div class="empty">No pincode has 2 or more orders with these filters. Try another branch, date or status.</div>`;

  singles.sort((a,b)=>a.earliest-b.earliest);
  $("singles").hidden=!singles.length;
  $("singles").innerHTML = singles.length ? `<summary>${singles.length} pincode${singles.length>1?"s":""} with a single order</summary>
    <div class="tbl"><table><thead><tr><th>Pincode</th><th>Order ID</th><th>Customer</th><th>Status</th><th>Delivery</th><th>Travel</th><th>Amount</th><th>Branch</th></tr></thead><tbody>${
      singles.map(g=>rowHTML(g.orders[0],null,false).replace("<tr>",`<tr><td class="nowrap"><b>${esc(g.pin)}</b><div class="dim pin-city">${esc(g.cities[0]||"")}</div></td>`)).join("")
    }</tbody></table></div>` : "";
}

/* ---------- Copy ---------- */
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove("show"),1600)}
function copyText(text,msg){
  const fallback=()=>{const ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();let ok=false;try{ok=document.execCommand("copy")}catch(e){}ta.remove();toast(ok?msg:"Copy blocked by the browser. Select and copy manually.")};
  if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(()=>toast(msg),fallback)}else fallback();
}
function joinIds(ids){return ids.join($("copyFmt").value==="comma"?", ":"\n")}

/* ---------- Events ---------- */
const drop=$("drop"),file=$("file");
drop.addEventListener("click",()=>file.click());
drop.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();file.click()}});
file.addEventListener("change",()=>{if(file.files[0])readFile(file.files[0]);file.value=""});
["dragenter","dragover"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add("over")}));
["dragleave","drop"].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove("over")}));
drop.addEventListener("drop",e=>{const f=e.dataTransfer.files[0];if(f)readFile(f)});
$("usePaste").addEventListener("click",readPaste);
$("loadNew").addEventListener("click",()=>{ALL=[];ELIGIBLE=[];checked.clear();doneSet.clear();$("lanes").innerHTML="";$("singles").innerHTML="";$("results").hidden=true;$("intake").hidden=false;$("topActions").hidden=true;$("paste").value="";window.scrollTo(0,0)});

try{localStorage.removeItem("pc_done")}catch(e){}
$("copyFmt").value=store.get("pc_fmt","line"); // only the copy-format preference is saved
$("copyFmt").addEventListener("change",e=>store.set("pc_fmt",e.target.value));
$("fBranch").addEventListener("change",e=>{state.branch=e.target.value;render()});
$("fDate").addEventListener("change",e=>{state.date=e.target.value;render()});
$("fSort").addEventListener("change",e=>{state.sort=e.target.value;render()});
$("fSearch").addEventListener("input",e=>{state.q=e.target.value.trim();render()});
$("fHideDone").addEventListener("change",e=>{state.hideDone=e.target.checked;render()});
$("fStatus").addEventListener("click",e=>{
  const b=e.target.closest("[data-s]");if(!b)return;
  const s=b.dataset.s;
  if(state.statuses.has(s)){if(state.statuses.size===1)return;state.statuses.delete(s)}else state.statuses.add(s);
  b.setAttribute("aria-pressed",state.statuses.has(s));render();
});

document.addEventListener("click",e=>{
  const c=e.target.closest("[data-copy]");
  if(c){copyText(c.dataset.copy,"Copied "+c.dataset.copy);return}
  const l=e.target.closest("[data-copylane]");
  if(l){
    const lane=l.closest(".lane");
    const ids=[...lane.querySelectorAll("[data-row]")].filter(x=>x.checked).map(x=>x.dataset.row);
    if(ids.length) copyText(joinIds(ids),`Copied ${ids.length} order ID${ids.length>1?"s":""}`);
  }
});
document.addEventListener("change",e=>{
  const r=e.target.closest("[data-row]");
  if(r){
    checked.set(r.dataset.row,r.checked);
    const lane=r.closest(".lane"),btn=lane.querySelector("[data-copylane]");
    const n=[...lane.querySelectorAll("[data-row]")].filter(x=>x.checked).length;
    btn.textContent=`Copy ${n} ID${n===1?"":"s"}`;btn.disabled=!n;return;
  }
  const d=e.target.closest("[data-done]");
  if(d){
    d.checked?doneSet.add(d.dataset.done):doneSet.delete(d.dataset.done);
    render();
  }
});
})();
